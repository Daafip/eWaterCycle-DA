# eWaterCycle-DA
[![Documentation Status](https://readthedocs.org/projects/ewatercycle-da/badge/?version=latest)](https://ewatercycle-da.readthedocs.io/en/latest/?badge=latest)

Code to run Data Assimilation with hydrological models on the [eWaterCycle](https://github.com/eWaterCycle/ewatercycle) platform. 


## docs:
Documenation can be found [here](https://ewatercycle-da.readthedocs.io/en/latest/)